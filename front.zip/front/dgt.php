<?php include('header.php') ?>

</head>

<body>

  <?php include('navbar.php') ?>

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>DTG Direct to Garments </h2>
          <ol>
            <li><a href="index.php">Home</a></li>
            <li>DTG Direct to Garments </li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->




  </main><!-- End #main -->

    <?php include('footer.php') ?>

</body>

</html>
