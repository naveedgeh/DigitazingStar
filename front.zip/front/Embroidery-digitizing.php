<?php include('header.php') ?>

</head>

<body>

  <?php include('navbar.php') ?>

  <main id="main">

    <!-- ======= Breadcrumbs ======= -->
    <section class="breadcrumbs">
      <div class="container">

        <div class="d-flex justify-content-between align-items-center">
          <h2>Embroidery digitizing</h2>
          <ol>
            <li><a href="index.php">Home</a></li>
            <li>Embroidery digitizing</li>
          </ol>
        </div>

      </div>
    </section><!-- End Breadcrumbs -->

    <section class="main-section">
      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-title">
              <span>Embroidery digitizing</span>
              <h2>
                High quality Embroidery digitizing services </h2>
              <p style="width:90%;margin:auto">Digitizing Star is the place where you find the best embroidery digitizing services at competitive prices. We are here with a vision to satisfy our valued clients.
                Welcome to our website, here at Digitizing Star you will get high-quality embroidery digitizing services. We are offering a wide variety of digitizing services as we have qualified and professional staff. You are going to find your favourite digitized design for your business or personal use. Undoubtedly, we are offering our best services for a long time here to our valued clients. If you are also looking for digitizing assistance, then you have come to the right place.</p>
                <a href="#about" class="btn-get-started scrollto animate__animated animate__fadeInUp">GET QUOTE</a>
            </div>


          </div>

            </div>
            <div class="row" id="secong-section">
              <div class="col-md-6">
                <h2>Why choose us?</h2>
                <p>Being professionals, we are providing a platform where you get the best-digitized designers done for any purpose. Our aim is to satisfy our clients providing them what they expect from us. Therefore, we have always satisfied our clients through the incredible services of embroidery digitized services. There is nothing about auto digitizing in our company. All of our digitized designs are drawn with hands. That’s an important reason we achieve high quality in this embroidery digitization process.
                    You will get your task done within no time at reasonable and competitive prices.  As we have our staff with the relevant backgrounds so we can easily meet the requirements and demands of anyone.</p>

              </div>
              <div class="col-md-6">
                  <img src="assets/img/slide/services1.png" width="100%" height="400px" alt="">
              </div>
            </div>


  </div>

      <div class="container">
        <div class="row">
          <div class="col-md-12">
            <div class="section-title" style="text-align:left">
              <span>services</span>
              <h2>
                Our common digitizing services </h2>
              <p style="width:90%;margin:auto">Whether you need logo digitizing for promotional purpose or another type of digitizing. You will get high-quality work through the manual process. We use the cutting edge technology to catch maximum quality in the digitized designs. So, apply it on the caps, T-shirts, or another type of garments. We ensure the best results whatever you choose for.</p>

            </div>

                <ul>
                  <li><h3>Cap digitizing</h3></li>
                  <p>Our professional cap digitizing services can make your caps very interesting and unique. Whether these are your business caps or used for another purpose. We can design them according to your requirements and demands.</p>
                  <li><h3>Shirt digitizing</h3></li>
                  <p>This is the most common type of embroidery digitizing service we are offering to our clients. In shirt digitizing, we design your shirts with high-quality printing machines and apply the best embroidery designs. Customize your T-shirt through our digitizing services and give an identity to your brand.</p>
                  <li><h3>Towel punch embroidery</h3></li>
                  <p>What is more interesting than having beautiful embroidery on your towel? Our towel punch embroidery services are available at competitive prices. We have a qualified and talented staff that is working on towel punch embroidery services. We welcome you at Digitizing Star where you find amazing manual embroidery services. The long-lasting embroidery make our services more special and valuable.</p>
                    <li><h3>Jacket back digitizing</h3></li>
                    <p>Furthermore, the jacket back digitizing is our popular service in which you get your jackets designed through high quality unique digitized designs. Our jacket back designs are totally hand digitized. Therefore, they give a unique and impressive look at the jackets.</p>
                    <li><h3>Uniform digitizing:</h3></li>
                    <p>Whether it’s a school uniform, sports club uniform, or another type of uniform. We can customize it through our professional services of embroidery digitizing. We are proud in our services as we have hundreds of satisfied clients that get uniform digitizing services from our platform.</p>
                  <ul>
          </div>
        </div>
      </div>
    </section>





  </main><!-- End #main -->

    <?php include('footer.php') ?>

</body>

</html>
