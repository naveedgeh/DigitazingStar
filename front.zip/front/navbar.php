<!-- ======= Top Bar ======= -->
<section id="topbar" class="d-none d-lg-block">
  <div class="container d-flex">
    <div class="contact-info mr-auto">
      <i class="icofont-envelope"></i><a href="mailto:suppot@digitizingstar.com">suppot@digitizingstar.com</a>
        <a href="#" class="twitter"><i class="icofont-bag phone-icon"> </i> Check Our Latest Priceing & plans</a>

    </div>
    <div class="social-links">
      <a href="/d/user/" class="twitter"><i class="icofont-login"> Login</i></a>
      <a href="/d/user/Register.php" class="facebook"><i class="icofont-user"> Register</i></a>
      <a href="/MyBiz/contact.php" class="instagram"><i class="icofont-email"> Get Quote</i></a>

    </div>
  </div>
</section>

<!-- ======= Header ======= -->
<header id="header" class="d-flex align-items-center">
  <div class="container d-flex align-items-center">

    <div class="logo mr-auto">
      <!-- <h1 class="text-light"><a href="index.html">Digitizing<span>Stars</span></a></h1> -->
      <!-- Uncomment below if you prefer to use an image logo -->
      <a href="index.html"><img src="assets/img/logo.png" alt="" class="img-fluid"></a>
    </div>

    <nav class="nav-menu d-none d-lg-block">
      <ul>
        <li class="active"><a href="/mybiz/">Home</a></li>

        <li class="drop-down"><a href="#">Services</a>
          <ul>
            <li><a href="/mybiz/embroidery-digitizing.php">Embroidery Digitizing</a></li>
            <li><a href="/mybiz/vector-art.php">Vector art, raster to vectors</a></li>
            <li><a href="/mybiz/dgt.php">DTG Direct to Garments</a></li>
            <li><a href="/mybiz/clipping.php">Clipping</a></li>
          </ul>
        </li>
        <li><a href="/mybiz/pricing-plans.php">Pricing & Plans</a></li>
        <li><a href="/mybiz/contact.php">Contact</a></li>

      </ul>
    </nav><!-- .nav-menu -->

  </div>
</header><!-- End Header -->
